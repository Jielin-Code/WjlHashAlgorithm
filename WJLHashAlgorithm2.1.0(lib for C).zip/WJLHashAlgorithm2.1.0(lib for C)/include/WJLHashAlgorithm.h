/**************************************************************************
 * Based on Weighted Probability Model Code(Jielin Code), the secure hash algorithm of
 * hash value length and digital password can be customized.
 * 1��Fixed some BUG
 * 2��Synchronize release C and JAVA releases
 * @author JieLin Wang(China)
 * @testing Aamir(Pakistan), Lei Xiao(China)
 * @copyright JieLin Wang 2020-08-18
 * @Version 2.0.1
 * @email 254908447@qq.com
 */
#ifndef _WJLHashAlgorithm_h
#define _WJLHashAlgorithm_h


 /*************************************************************************************
 the main Wang Jie lin hash function
 InBytesBuFF: the first address of bytes cache waiting to be encoding.
 InBytesBuFF_Length: the bytes cache length.
 keyt: digital key, 0-999999,by user-defined or system-defined.
 ByteLength: the hash value's byte length, by user-defined or system-defined.
 *************************************************************************************/
unsigned char * encrypt(unsigned char *inputString, int secretKey, int byteLength);
#endif